# Mahasa's Circle — React Foundation v7.0

**Carry the Torch. Light the Way.**

This is the first proper application foundation for Mahasa's Circle.

## Working routes

- `#/` — approved portrait landing page
- `#/sanctuary` — living Circle dashboard
- `#/forge` — personal sigil Forge
- `#/torch` — personal Torch page

## Preserved work

The complete v6.1 static demo is stored in `/legacy-demo` so no prior work is lost.

## Local development

```bash
npm install
npm run dev
```

## Netlify

- Build command: `npm run build`
- Publish directory: `dist`

The included `netlify.toml` configures these settings automatically.

## Current foundation

- React + Vite
- Reusable flame transition
- Mobile-first navigation
- Living Sanctuary dashboard
- Personal Sigil Forge
- Personal Torch page
- Browser-based demo storage

## Next build

Recreate and connect:
- Mirror
- Compass
- Loom
- Silver Thread journey
- Shared Campfire
- Hearths
- Local Circle
- Marketplace
- Library
