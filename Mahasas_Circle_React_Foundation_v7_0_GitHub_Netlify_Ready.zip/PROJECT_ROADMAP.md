# Mahasa's Circle Roadmap

## Locked and working
1. React/Vite project foundation
2. Portrait landing page
3. Realistic flame transition
4. Living Sanctuary dashboard
5. Personal Sigil Forge
6. Personal Torch page
7. Legacy v6.1 archive

## Next milestones
1. Mirror reflection experience
2. Compass matching and path discovery
3. Loom connection map
4. Silver Thread offering flow
5. Shared Journey and Campfire
6. Real Hearth pages
7. Local Circle privacy model
8. Marketplace and Library
9. Authentication and database
10. Public beta preparation
