import React, { useEffect } from 'react';

export default function FlameTransition({ active, onComplete, title = 'Carry the torch.', subtitle = 'The Circle opens.' }) {
  useEffect(() => {
    if (!active) return;
    const timer = setTimeout(onComplete, 2450);
    return () => clearTimeout(timer);
  }, [active, onComplete]);

  if (!active) return null;

  return (
    <div className="flame-transition" aria-live="polite">
      <div className="flame-darken" />
      <div className="embers">
        {Array.from({ length: 18 }).map((_, index) => (
          <i key={index} style={{
            '--x': `${4 + index * 5.2}%`,
            '--delay': `${(index % 7) * 0.08}s`,
            '--scale': `${0.65 + (index % 5) * 0.14}`,
          }} />
        ))}
      </div>
      <div className="flame-bed">
        {Array.from({ length: 9 }).map((_, index) => <span key={index} className={`flame-tongue flame-${index + 1}`} />)}
      </div>
      <div className="heat-haze" />
      <div className="flame-lens" />
      <div className="transition-copy">
        <strong>{title}</strong>
        <span>{subtitle}</span>
      </div>
    </div>
  );
}
