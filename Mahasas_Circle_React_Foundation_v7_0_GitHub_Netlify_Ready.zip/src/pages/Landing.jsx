import React, { useState } from 'react';
import FlameTransition from '../components/FlameTransition';

export default function Landing({ navigate }) {
  const [transition, setTransition] = useState(null);

  const enter = (target, title, subtitle) => setTransition({ target, title, subtitle });

  return (
    <main className="landing-page">
      <div className="landing-blur" />
      <section className="landing-art" aria-label="Mahasa's Circle moonlit portal">
        <button className="landing-hit join" onClick={() => enter('/forge', 'Forge your sigil.', 'Light your first torch.')} aria-label="Join the Circle" />
        <button className="landing-hit enter" onClick={() => enter('/sanctuary', 'Carry the torch.', 'The Circle opens.')} aria-label="Enter the Circle" />
        <button className="landing-hit member" onClick={() => enter('/forge', 'Forge your sigil.', 'Light your first torch.')} aria-label="Become a Member" />
        <button className="landing-hit journey" onClick={() => enter('/sanctuary', 'Begin your journey.', 'The path opens.')} aria-label="Begin your journey" />
      </section>

      <FlameTransition
        active={Boolean(transition)}
        title={transition?.title}
        subtitle={transition?.subtitle}
        onComplete={() => navigate(transition.target)}
      />
    </main>
  );
}
