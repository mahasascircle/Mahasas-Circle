import React, { useMemo } from 'react';
import { BookOpen, CalendarDays, Flame, MapPin, MessageCircle, Moon, Search, ShoppingBag, Users } from 'lucide-react';
import BottomNav from '../components/BottomNav';

const sections = [
  ['Silver Threads', MessageCircle, 'Private conversations with trusted members.'],
  ['Hearths', Flame, 'Communities for every path.'],
  ['Local Circle', MapPin, 'Find people, shops, and events nearby.'],
  ['Gatherings', CalendarDays, 'Events, rituals, classes, and celebrations.'],
  ['Marketplace', ShoppingBag, 'Artisans, tools, and treasures.'],
  ['Library', BookOpen, 'Knowledge preserved by the Circle.'],
  ['My Torch', Flame, 'Your living sigil and the light you carry.'],
  ['The Loom', Users, 'See the connections woven through your journey.'],
];

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  if (hour < 21) return 'Good evening';
  return 'Welcome home';
}

export default function Sanctuary({ navigate }) {
  const name = useMemo(() => {
    try { return JSON.parse(localStorage.getItem('mahasaProfile') || '{}').name || 'Bill'; }
    catch { return 'Bill'; }
  }, []);

  return (
    <main className="sanctuary-page">
      <header className="sanctuary-top">
        <div className="brand-small"><Flame size={23} /> MAHASA'S CIRCLE</div>
        <label className="sanctuary-search"><Search size={17} /><input placeholder="Search the Circle" /></label>
        <button className="round-button" onClick={() => navigate('/torch')}><Flame size={18} /></button>
      </header>

      <section className="sanctuary-hero">
        <div className="hero-copy">
          <p className="eyebrow">Inside the Circle</p>
          <h1>{greeting()}, {name}.</h1>
          <p>The Circle is awake. Your Torch is burning. Your path is yours.</p>
          <div className="hero-stats">
            <div><strong>18</strong><span>New Threads</span></div>
            <div><strong>3</strong><span>Gatherings</span></div>
            <div><strong>12</strong><span>Library Additions</span></div>
            <div><strong>6</strong><span>New Artisans</span></div>
          </div>
        </div>
        <div className="living-moon" aria-hidden="true"><Moon size={72} /></div>
      </section>

      <section className="section-block">
        <div className="section-heading"><h2>Explore the Circle</h2><span>Every path begins with a single step.</span></div>
        <div className="sanctuary-grid">
          {sections.map(([title, Icon, copy]) => (
            <button key={title} className="sanctuary-card" onClick={() => title === 'My Torch' ? navigate('/torch') : undefined}>
              <Icon size={30} />
              <h3>{title}</h3>
              <p>{copy}</p>
              <span>Explore →</span>
            </button>
          ))}
        </div>
      </section>

      <section className="living-row">
        <article><Moon size={34}/><div><span>Current Moon</span><strong>Waxing Crescent</strong></div></article>
        <article><Flame size={34}/><div><span>The Flame Grows Stronger</span><strong>Every act of kindness adds light.</strong></div></article>
        <article><Users size={34}/><div><span>Today's Intention</span><strong>Carry the Torch. Light the Way.</strong></div></article>
      </section>

      <BottomNav navigate={navigate} active="Compass" />
    </main>
  );
}
